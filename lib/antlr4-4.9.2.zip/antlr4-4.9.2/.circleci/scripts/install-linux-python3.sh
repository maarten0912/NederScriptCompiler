#!/bin/bash

set -euo pipefail

echo "installing python 3..."
sudo apt-get update -y
sudo apt-get install python3
echo "done installing python 3"
